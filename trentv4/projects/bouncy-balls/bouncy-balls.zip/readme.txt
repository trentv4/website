You need Java!

Be sure to extract this folder!

WINDOWS:
Double-click either the .jar file or the .exe. 

MAC OSX:
I don't know. The jar, maybe? I've never used a Mac. It has the natives for OSX.

LINUX:
This has the default linux natives. If you're using *nix you should know how to run this.